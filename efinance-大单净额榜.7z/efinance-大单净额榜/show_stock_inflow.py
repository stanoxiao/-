import pandas as pd
from datetime import datetime
from stock_inflow_db import StockInflowDB
import streamlit as st

def main():
    st.set_page_config(page_title="股票资金流向分析", layout="wide")
    st.title("股票资金流向分析系统")
    
    # 初始化数据库
    db = StockInflowDB()
    
    # 侧边栏：选择功能
    st.sidebar.title("功能选择")
    function = st.sidebar.radio(
        "选择功能",
        ["资金流向排名", "个股资金流向图", "更新数据"]
    )
    
    if function == "资金流向排名":
        st.header("资金流向排名")
        
        # 时间选择
        col1, col2 = st.columns(2)
        with col1:
            start_time = st.text_input("开始时间", "2024-03-20 09:30")
        with col2:
            end_time = st.text_input("结束时间", "2024-03-20 10:00")
        
        if st.button("查询排名"):
            result = db.get_inflow_ranking(start_time, end_time)
            st.dataframe(result)
    
    elif function == "个股资金流向图":
        st.header("个股资金流向图")
        
        # 股票代码输入
        stock_code = st.text_input("输入股票代码", "300750")
        
        # 时间选择
        col1, col2 = st.columns(2)
        with col1:
            start_time = st.text_input("开始时间", "2024-03-20 09:30")
        with col2:
            end_time = st.text_input("结束时间", "2024-03-20 10:00")
        
        if st.button("显示图表"):
            db.plot_stock_inflow(stock_code, start_time, end_time)
    
    elif function == "更新数据":
        st.header("更新数据")
        if st.button("更新当日数据"):
            with st.spinner("正在更新数据..."):
                db.update_today_data()
            st.success("数据更新完成！")

if __name__ == "__main__":
    main() 