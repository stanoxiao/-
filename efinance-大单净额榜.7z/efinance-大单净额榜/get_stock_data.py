import pandas as pd
from efinance.common.getter import get_realtime_quotes_by_fs, get_today_bill
from datetime import datetime
import sqlite3
import streamlit as st
import plotly.graph_objects as go
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import List, Dict
import threading
import time

class StockDataManager:
    def __init__(self, db_path='stock_data.db'):
        self.db_path = db_path
        self.init_db()
        self._lock = threading.Lock()  # 添加线程锁
        self._connection_pool = []  # 数据库连接池
        self._max_connections = 20  # 最大连接数
        self._connection_lock = threading.Lock()
    
    def init_db(self):
        """初始化数据库"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # 创建股票资金流向表（添加唯一约束）
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS stock_inflow (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            stock_code TEXT NOT NULL,
            stock_name TEXT NOT NULL,
            time DATETIME NOT NULL,
            main_inflow REAL,
            small_inflow REAL,
            medium_inflow REAL,
            large_inflow REAL,
            super_inflow REAL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(stock_code, time)  -- 添加唯一约束
        )
        ''')
        
        # 创建索引（保持不变）
        cursor.execute('''
        CREATE INDEX IF NOT EXISTS idx_stock_time 
        ON stock_inflow(stock_code, time)
        ''')
        
        conn.commit()
        conn.close()
    
    def get_connection(self):
        """从连接池获取数据库连接"""
        with self._connection_lock:
            if not self._connection_pool:
                return sqlite3.connect(self.db_path)
            return self._connection_pool.pop()
    
    def return_connection(self, conn):
        """归还数据库连接到连接池"""
        with self._connection_lock:
            if len(self._connection_pool) < self._max_connections:
                self._connection_pool.append(conn)
            else:
                conn.close()
    
    # 修改保存方法，使用 INSERT OR IGNORE
    def save_data(self, data_list):
        """批量保存数据到数据库（自动去重）"""
        with self._lock:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            cursor.execute('BEGIN TRANSACTION')
            values = [(
                data['代码'], data['名称'], data['时间'],
                data['主力净流入'], data['小单净流入'], data['中单净流入'],
                data['大单净流入'], data['超大单净流入']
            ) for data in data_list]
            
            # 使用 INSERT OR IGNORE 避免重复
            cursor.executemany('''
            INSERT OR IGNORE INTO stock_inflow 
            (stock_code, stock_name, time, main_inflow, small_inflow, medium_inflow, large_inflow, super_inflow)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', values)
            
            cursor.execute('COMMIT')
            self.return_connection(conn)
    
    def get_ranking(self, start_time: str, end_time: str) -> pd.DataFrame:
        """获取指定时间范围内的资金流向排名"""
        conn = self.get_connection()
        
        query = '''
        SELECT 
            stock_code as 代码,
            stock_name as 名称,
            time as 时间,
            SUM(main_inflow) as 主力净流入,
            SUM(small_inflow) as 小单净流入,
            SUM(medium_inflow) as 中单净流入,
            SUM(large_inflow) as 大单净流入,
            SUM(super_inflow) as 超大单净流入
        FROM stock_inflow
        WHERE time BETWEEN ? AND ?
        GROUP BY stock_code, stock_name, time
        ORDER BY time DESC, 超大单净流入 DESC
        '''
        
        df = pd.read_sql_query(query, conn, params=(start_time, end_time))
        self.return_connection(conn)
        
        return df
    
    def get_stock_history(self, stock_code: str, start_time: str, end_time: str) -> pd.DataFrame:
        """获取单个股票的历史数据"""
        conn = sqlite3.connect(self.db_path)
        
        query = '''
        SELECT 
            time as 时间,
            main_inflow as 主力净流入,
            small_inflow as 小单净流入,
            medium_inflow as 中单净流入,
            large_inflow as 大单净流入,
            super_inflow as 超大单净流入
        FROM stock_inflow
        WHERE stock_code = ? AND time BETWEEN ? AND ?
        ORDER BY time
        '''
        
        df = pd.read_sql_query(query, conn, params=(stock_code, start_time, end_time))
        conn.close()
        
        return df

    def get_database_info(self) -> Dict:
        """获取数据库基本信息"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # 获取表信息
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = cursor.fetchall()
        
        # 获取stock_inflow表的信息
        cursor.execute("SELECT COUNT(*) FROM stock_inflow")
        total_records = cursor.fetchone()[0]
        
        # 获取时间范围
        cursor.execute("SELECT MIN(time), MAX(time) FROM stock_inflow")
        time_range = cursor.fetchone()
        
        # 获取股票数量
        cursor.execute("SELECT COUNT(DISTINCT stock_code) FROM stock_inflow")
        stock_count = cursor.fetchone()[0]
        
        conn.close()
        
        return {
            "数据库文件": self.db_path,
            "表数量": len(tables),
            "表名": [table[0] for table in tables],
            "总记录数": total_records,
            "时间范围": f"{time_range[0]} 至 {time_range[1]}" if time_range[0] else "无数据",
            "股票数量": stock_count
        }
    
    def get_sample_data(self, limit: int = 10) -> pd.DataFrame:
        """获取样本数据"""
        conn = sqlite3.connect(self.db_path)
        query = '''
        SELECT 
            stock_code as 代码,
            stock_name as 名称,
            time as 时间,
            main_inflow as 主力净流入,
            small_inflow as 小单净流入,
            medium_inflow as 中单净流入,
            large_inflow as 大单净流入,
            super_inflow as 超大单净流入
        FROM stock_inflow
        ORDER BY time DESC, stock_code
        LIMIT ?
        '''
        df = pd.read_sql_query(query, conn, params=(limit,))
        conn.close()
        return df

def process_single_stock(row: pd.Series) -> List[Dict]:
    """处理单只股票的数据，获取所有时间点的数据"""
    code = row['代码']
    try:
        # 添加重试机制
        max_retries = 3
        for attempt in range(max_retries):
            try:
                bill_df = get_today_bill(code)
                if not bill_df.empty:
                    result = []
                    for _, bill_row in bill_df.iterrows():
                        # 确保时间字段完整且格式正确
                        time_str = bill_row['时间']
                        if not time_str or len(time_str) < 16:  # 检查时间格式是否完整
                            print(f"跳过不完整的时间记录: {time_str}")
                            continue
                            
                        # 验证时间格式
                        try:
                            datetime.strptime(time_str, '%Y-%m-%d %H:%M')
                        except ValueError:
                            print(f"跳过格式错误的时间记录: {time_str}")
                            continue
                            
                        # 确保所有数值字段都存在且不为空
                        if pd.isna(bill_row['主力净流入']) or pd.isna(bill_row['小单净流入']) or \
                           pd.isna(bill_row['中单净流入']) or pd.isna(bill_row['大单净流入']) or \
                           pd.isna(bill_row['超大单净流入']):
                            print(f"跳过包含空值的记录: {time_str}")
                            continue
                            
                        data = {
                            '代码': code,
                            '名称': row['名称'],
                            '时间': time_str,
                            '主力净流入': float(bill_row['主力净流入']),
                            '小单净流入': float(bill_row['小单净流入']),
                            '中单净流入': float(bill_row['中单净流入']),
                            '大单净流入': float(bill_row['大单净流入']),
                            '超大单净流入': float(bill_row['超大单净流入'])
                        }
                        result.append(data)
                    
                    # 按时间排序
                    result.sort(key=lambda x: x['时间'])
                    print(f"股票 {code} 获取到 {len(result)} 条数据，时间范围: {result[0]['时间']} 至 {result[-1]['时间']}")
                    return result
            except Exception as e:
                if attempt == max_retries - 1:
                    raise e
                time.sleep(0.1)  # 短暂延迟后重试
    except Exception as e:
        print(f"获取股票 {code} 数据时出错: {str(e)}")
    return []

def check_data_integrity(df: pd.DataFrame) -> Dict:
    """检查数据完整性"""
    checks = {
        "总记录数": len(df),
        "时间点数量": df['时间'].nunique(),
        "股票数量": df['代码'].nunique(),
        "时间范围": f"{df['时间'].min()} 至 {df['时间'].max()}",
        "空值统计": {
            "主力净流入": df['主力净流入'].isna().sum(),
            "小单净流入": df['小单净流入'].isna().sum(),
            "中单净流入": df['中单净流入'].isna().sum(),
            "大单净流入": df['大单净流入'].isna().sum(),
            "超大单净流入": df['超大单净流入'].isna().sum()
        },
        "异常值统计": {
            "主力净流入": len(df[df['主力净流入'].abs() > 1e9]),
            "小单净流入": len(df[df['小单净流入'].abs() > 1e9]),
            "中单净流入": len(df[df['中单净流入'].abs() > 1e9]),
            "大单净流入": len(df[df['大单净流入'].abs() > 1e9]),
            "超大单净流入": len(df[df['超大单净流入'].abs() > 1e9])
        }
    }
    return checks

def log_data_issues(checks: Dict):
    """记录数据问题"""
    print("\n=== 数据完整性检查报告 ===")
    print(f"总记录数: {checks['总记录数']}")
    print(f"时间点数量: {checks['时间点数量']}")
    print(f"股票数量: {checks['股票数量']}")
    print(f"时间范围: {checks['时间范围']}")
    
    print("\n空值统计:")
    for field, count in checks['空值统计'].items():
        if count > 0:
            print(f"警告: {field} 存在 {count} 个空值")
    
    print("\n异常值统计:")
    for field, count in checks['异常值统计'].items():
        if count > 0:
            print(f"警告: {field} 存在 {count} 个异常值（绝对值超过10亿）")

def get_stock_data():
    """获取股票资金流向数据"""
    print("\n=== 开始获取股票资金流向数据 ===")
    start_time = datetime.now()
    
    try:
        print("正在获取A股市场所有股票列表...")
        df = get_realtime_quotes_by_fs("m:0+t:6,m:0+t:13,m:0+t:80")
        print(f"成功获取到 {len(df)} 只股票")
        
        # 检查股票列表数据
        if df.empty:
            raise ValueError("获取到的股票列表为空")
        if df['代码'].isna().any():
            print("警告：股票列表中存在空代码")
        if df['名称'].isna().any():
            print("警告：股票列表中存在空名称")
        
        # 创建数据管理器
        manager = StockDataManager()
        
        # 获取当前日期
        today = datetime.now().strftime('%Y-%m-%d')
        print(f"\n当前日期: {today}")
        
        # 检查数据库中是否已有今天的数据
        conn = manager.get_connection()
        cursor = conn.cursor()
        
        # 检查今日数据完整性
        cursor.execute('''
            SELECT COUNT(*) as total,
                   COUNT(DISTINCT time) as time_points,
                   MIN(time) as first_time,
                   MAX(time) as last_time,
                   COUNT(DISTINCT stock_code) as stock_count
            FROM stock_inflow 
            WHERE date(time) = ?
        ''', (today,))
        stats = cursor.fetchone()
        today_count, time_points, first_time, last_time, stock_count = stats
        
        # 检查是否有完整的分钟数据
        expected_minutes = 240  # 4小时 * 60分钟
        if time_points:
            print(f"\n今日数据统计:")
            print(f"总记录数: {today_count}")
            print(f"时间点数量: {time_points}")
            print(f"股票数量: {stock_count}")
            print(f"最早时间: {first_time}")
            print(f"最新时间: {last_time}")
            print(f"数据完整性: {time_points}/{expected_minutes} 分钟")
            
            # 检查数据分布
            cursor.execute('''
                SELECT time, COUNT(*) as count
                FROM stock_inflow
                WHERE date(time) = ?
                GROUP BY time
                ORDER BY time
            ''', (today,))
            time_distribution = cursor.fetchall()
            
            # 检查时间间隔
            time_gaps = []
            for i in range(len(time_distribution) - 1):
                current_time = datetime.strptime(time_distribution[i][0], '%Y-%m-%d %H:%M')
                next_time = datetime.strptime(time_distribution[i + 1][0], '%Y-%m-%d %H:%M')
                gap = (next_time - current_time).total_seconds() / 60
                if gap > 1:
                    time_gaps.append((time_distribution[i][0], gap))
            
            if time_gaps:
                print("\n警告：发现时间间隔异常:")
                for time, gap in time_gaps:
                    print(f"时间点 {time} 到下一个时间点间隔 {gap:.1f} 分钟")
        
        manager.return_connection(conn)
        
        # 如果今天已经有完整数据，直接使用数据库中的数据
        if today_count > 0 and time_points >= expected_minutes * 0.95:  # 允许5%的缺失
            print("\n使用数据库中的今日数据...")
            result_df = manager.get_ranking(f"{today} 09:30", f"{today} 15:00")
            if not result_df.empty:
                # 检查数据完整性
                checks = check_data_integrity(result_df)
                log_data_issues(checks)
                
                # 获取最新时间点的数据
                latest_time = result_df['时间'].max()
                latest_df = result_df[result_df['时间'] == latest_time]
                
                # 保存最新时间点的数据到CSV
                filename = f"stock_inflow_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
                latest_df.to_csv(filename, index=False, encoding='utf-8-sig')
                print(f"\n数据已保存到文件: {filename}")
                
                # 显示最新时间点的前20名
                print(f"\n{latest_time} 超大单净流入排名前20的股票：")
                print(latest_df.head(20))
                
                # 显示数据统计信息
                print("\n数据统计信息：")
                print(f"总数据条数：{len(result_df)}")
                print(f"时间范围：{result_df['时间'].min()} 至 {result_df['时间'].max()}")
                print(f"股票数量：{result_df['代码'].nunique()}")
                return
            else:
                print("警告：数据库中的数据为空，将重新获取")
        
        # 如果没有今天的数据或数据不完整，则从网络获取
        print("\n从网络获取最新数据...")
        
        # 将股票列表分成多个批次
        batch_size = 100
        batches = [df[i:i + batch_size] for i in range(0, len(df), batch_size)]
        print(f"将处理 {len(batches)} 个批次，每批 {batch_size} 只股票")
        
        result_list = []
        processed_stocks = set()  # 用于跟踪已处理的股票
        failed_stocks = set()  # 用于跟踪失败的股票
        
        with ThreadPoolExecutor(max_workers=50) as executor:
            for batch_idx, batch in enumerate(batches, 1):
                print(f"\n处理第 {batch_idx}/{len(batches)} 批")
                
                # 过滤掉已处理的股票
                batch = batch[~batch['代码'].isin(processed_stocks)]
                if batch.empty:
                    print("该批次所有股票都已处理，跳过")
                    continue
                
                future_to_stock = {
                    executor.submit(process_single_stock, row): row 
                    for _, row in batch.iterrows()
                }
                
                total = len(batch)
                completed = 0
                batch_results = []
                
                for future in as_completed(future_to_stock):
                    completed += 1
                    row = future_to_stock[future]
                    try:
                        data_list = future.result()
                        if data_list:
                            batch_results.extend(data_list)
                            processed_stocks.add(row['代码'])
                            print(f"处理进度: {completed}/{total}: {row['代码']} {row['名称']} - 获取到 {len(data_list)} 条数据")
                        else:
                            failed_stocks.add(row['代码'])
                            print(f"警告: {row['代码']} {row['名称']} 未获取到数据")
                    except Exception as e:
                        failed_stocks.add(row['代码'])
                        print(f"处理股票 {row['代码']} 时出错: {str(e)}")
                
                # 批量保存数据
                if batch_results:
                    try:
                        manager.save_data(batch_results)
                        result_list.extend(batch_results)
                        print(f"成功保存第 {batch_idx} 批数据，共 {len(batch_results)} 条记录")
                    except Exception as e:
                        print(f"保存第 {batch_idx} 批数据时出错: {str(e)}")
        
        # 处理最终结果
        if result_list:
            result_df = pd.DataFrame(result_list)
            
            # 检查数据完整性
            checks = check_data_integrity(result_df)
            log_data_issues(checks)
            
            # 生成完整数据CSV
            full_filename = f"stock_inflow_full_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
            result_df.to_csv(full_filename, index=False, encoding='utf-8-sig')
            print(f"\n完整数据已保存到文件: {full_filename}")
            
            # 生成最新时间点的CSV
            latest_time = result_df['时间'].max()
            latest_df = result_df[result_df['时间'] == latest_time]
            latest_filename = f"stock_inflow_latest_{latest_time.replace(':','')}.csv"
            latest_df.to_csv(latest_filename, index=False, encoding='utf-8-sig')
            print(f"最新时间点数据已保存到文件: {latest_filename}")
            
            # 输出处理统计
            print("\n=== 处理统计 ===")
            print(f"成功处理股票数: {len(processed_stocks)}")
            print(f"失败股票数: {len(failed_stocks)}")
            if failed_stocks:
                print("失败的股票代码:", list(failed_stocks))
        else:
            print("警告：未能获取到任何数据")
            
    except Exception as e:
        print(f"\n发生错误: {str(e)}")
        raise
    finally:
        end_time = datetime.now()
        duration = end_time - start_time
        print(f"\n=== 数据获取完成 ===")
        print(f"总耗时: {duration}")
        print(f"开始时间: {start_time}")
        print(f"结束时间: {end_time}")

def show_visualization():
    """显示数据可视化界面"""
    st.set_page_config(page_title="股票资金流向分析", layout="wide")
    st.title("股票资金流向分析系统")
    
    # 初始化数据管理器
    manager = StockDataManager()
    
    # 侧边栏：选择功能
    st.sidebar.title("功能选择")
    function = st.sidebar.radio(
        "选择功能",
        ["数据库信息", "资金流向排名", "个股资金流向图", "更新数据"]
    )
    
    if function == "数据库信息":
        st.header("数据库信息")
        
        # 显示数据库基本信息
        info = manager.get_database_info()
        st.subheader("基本信息")
        for key, value in info.items():
            st.write(f"{key}: {value}")
        
        # 显示样本数据
        st.subheader("最新数据样本")
        sample_data = manager.get_sample_data(10)
        st.dataframe(sample_data)
        
        # 添加数据统计图表
        st.subheader("数据统计")
        if info["总记录数"] > 0:
            # 获取每日数据量统计
            conn = sqlite3.connect(manager.db_path)
            daily_stats = pd.read_sql_query('''
                SELECT date(time) as 日期, COUNT(*) as 记录数
                FROM stock_inflow
                GROUP BY date(time)
                ORDER BY 日期 DESC
                LIMIT 10
            ''', conn)
            conn.close()
            
            fig = go.Figure(data=[
                go.Bar(x=daily_stats['日期'], y=daily_stats['记录数'])
            ])
            fig.update_layout(
                title='每日数据量统计',
                xaxis_title='日期',
                yaxis_title='记录数'
            )
            st.plotly_chart(fig)
    
    elif function == "资金流向排名":
        st.header("资金流向排名")
        
        # 获取所有可用的时间点
        conn = sqlite3.connect(manager.db_path)
        time_points = pd.read_sql_query('''
            SELECT DISTINCT time as 时间点
            FROM stock_inflow
            ORDER BY time DESC
            LIMIT 100
        ''', conn)
        conn.close()
        
        # 时间选择
        selected_time = st.selectbox(
            "选择时间点",
            time_points['时间点'].tolist(),
            format_func=lambda x: f"{x}"
        )
        
        if selected_time:
            # 获取该时间点的排名
            result = manager.get_ranking(selected_time, selected_time)
            st.write(f"### {selected_time} 资金流向排名")
            st.dataframe(result)
            
            # 添加资金流向分布图
            fig = go.Figure()
            for col in ['主力净流入', '小单净流入', '中单净流入', '大单净流入', '超大单净流入']:
                fig.add_trace(go.Bar(
                    x=result['代码'].head(20),
                    y=result[col].head(20),
                    name=col
                ))
            
            fig.update_layout(
                title='前20名股票资金流向分布',
                xaxis_title='股票代码',
                yaxis_title='金额',
                barmode='group'
            )
            st.plotly_chart(fig)
    
    elif function == "个股资金流向图":
        st.header("个股资金流向图")
        
        # 股票代码输入
        stock_code = st.text_input("输入股票代码", "300750")
        
        # 获取该股票的所有可用日期
        conn = sqlite3.connect(manager.db_path)
        dates = pd.read_sql_query('''
            SELECT DISTINCT date(time) as 日期
            FROM stock_inflow
            WHERE stock_code = ?
            ORDER BY 日期 DESC
        ''', conn, params=(stock_code,))
        conn.close()
        
        if not dates.empty:
            selected_date = st.selectbox(
                "选择日期",
                dates['日期'].tolist(),
                format_func=lambda x: f"{x}"
            )
            
            if selected_date:
                start_time = f"{selected_date} 09:30"
                end_time = f"{selected_date} 15:00"
                
                df = manager.get_stock_history(stock_code, start_time, end_time)
                
                if not df.empty:
                    fig = go.Figure()
                    for col in ['主力净流入', '小单净流入', '中单净流入', '大单净流入', '超大单净流入']:
                        fig.add_trace(go.Scatter(
                            x=df['时间'],
                            y=df[col],
                            name=col,
                            mode='lines+markers'
                        ))
                    
                    fig.update_layout(
                        title=f'股票{stock_code}资金流向图',
                        xaxis_title='时间',
                        yaxis_title='金额',
                        hovermode='x unified'
                    )
                    
                    st.plotly_chart(fig)
                else:
                    st.warning("该时间段没有数据")
        else:
            st.warning("未找到该股票的数据")
    
    elif function == "更新数据":
        st.header("更新数据")
        if st.button("强制更新数据（即使已有今日数据）"):
            with st.spinner("正在获取最新数据..."):
                get_stock_data()
            st.success("数据更新完成！")

if __name__ == "__main__":
    # 获取数据
    get_stock_data()
    
    # 显示可视化界面
    show_visualization() 