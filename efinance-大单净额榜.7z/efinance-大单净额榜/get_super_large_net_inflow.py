import pandas as pd
from efinance.common.getter import get_realtime_quotes_by_fs, get_today_bill
from efinance.common.config import MarketType
from datetime import datetime
from stock_inflow_db import StockInflowDB

def get_super_large_net_inflow():
    """
    获取全市场股票超大单净流入排序
    
    Returns
    -------
    DataFrame
        包含股票代码、名称、超大单净流入等信息的DataFrame
    """
    # 获取A股市场所有股票数据
    df = get_realtime_quotes_by_fs("m:0+t:6,m:0+t:13,m:0+t:80")
    
    # 获取每只股票的当日超大单净流入数据
    result_list = []
    
    for _, row in df.iterrows():
        code = row['代码']
        try:
            # 获取当日超大单净流入数据
            bill_df = get_today_bill(code)
            if not bill_df.empty:
                # 获取最新一条数据的超大单净流入
                latest_inflow = bill_df.iloc[-1]['超大单净流入']
                print(latest_inflow)
                result_list.append({
                    '代码': code,
                    '名称': row['名称'],
                    '超大单净流入': latest_inflow
                })
        except Exception as e:
            print(f"获取股票 {code} 数据时出错: {str(e)}")
            continue
    
    # 创建DataFrame并排序
    result_df = pd.DataFrame(result_list)
    if not result_df.empty:
        result_df = result_df.sort_values('超大单净流入', ascending=False)
    
    return result_df

if __name__ == "__main__":
    print("正在获取全市场股票超大单净流入排序...")
    result = get_super_large_net_inflow()
    if not result.empty:
        print("\n超大单净流入排名前20的股票：")
        print(result.head(20))
    else:
        print("未能获取到任何数据")

# 查询今日9:30-10:00的数据
today = datetime.now().strftime('%Y-%m-%d')
db = StockInflowDB()
result = db.get_inflow_ranking(f"{today} 09:30", f"{today} 10:00")
print(result.head(20))

# 查询其他时间范围
result = db.get_inflow_ranking("2024-03-20 09:30", "2024-03-20 10:00") 